package com.mcnz;

public class BreakMeMaybe {
	
	// remove the semi-colon in the next line to break the build with a compile error
	public static final int MAX_COUNT = 0;
	
}